// Automatically generated C++ file on Thu Jul  4 15:02:20 2024
//
// To build with Digital Mars C++ Compiler:
//
//    dmc -mn -WD dq0_abc.cpp kernel32.lib

#include <stdio.h>
#include <malloc.h>
#include <stdarg.h>
#include <time.h>
#include <math.h>

union uData
{
   bool b;
   char c;
   unsigned char uc;
   short s;
   unsigned short us;
   int i;
   unsigned int ui;
   float f;
   double d;
   long long int i64;
   unsigned long long int ui64;
   char *str;
   unsigned char *bytes;
};

// int DllMain() must exist and return 1 for a process to load the .DLL
// See https://docs.microsoft.com/en-us/windows/win32/dlls/dllmain for more information.
int __stdcall DllMain(void *module, unsigned int reason, void *reserved) { return 1; }

void display(const char *fmt, ...)
{ // for diagnostic print statements
   msleep(30);
   fflush(stdout);
   va_list args = { 0 };
   va_start(args, fmt);
   vprintf(fmt, args);
   va_end(args);
   fflush(stdout);
   msleep(30);
}

void bzero(void *ptr, unsigned int count)
{
   unsigned char *first = (unsigned char *) ptr;
   unsigned char *last  = first + count;
   while(first < last)
      *first++ = '\0';
}

// #undef pin names lest they collide with names in any header file(s) you might include.
#undef d
#undef q
#undef theta
#undef a
#undef b
#undef c
#undef o

struct sDQ0_ABC
{
  // declare the structure here
};

extern "C" __declspec(dllexport) void dq0_abc(struct sDQ0_ABC **opaque, double t, union uData *data)
{
   double  d     = data[0].d; // input
   double  q     = data[1].d; // input
   double  theta = data[2].d; // input
   double  o     = data[3].d; // input
   double &a     = data[4].d; // output
   double &b     = data[5].d; // output
   double &c     = data[6].d; // output

   if(!*opaque)
   {
      *opaque = (struct sDQ0_ABC *) malloc(sizeof(struct sDQ0_ABC));
      bzero(*opaque, sizeof(struct sDQ0_ABC));
   }
   struct sDQ0_ABC *inst = *opaque;

// Implement module evaluation code here:
a = d*cos(theta) + q*sin(theta) + o;
b = d*cos(theta-2*M_PI/3) + q*sin(theta-2*M_PI/3) + o;
c = d*cos(theta+2*M_PI/3) + q*sin(theta+2*M_PI/3) + o;
}

extern "C" __declspec(dllexport) double MaxExtStepSize(struct sDQ0_ABC *inst)
{
   return 1e308; // implement a good choice of max timestep size that depends on struct sDQ0_ABC
}

extern "C" __declspec(dllexport) void Trunc(struct sDQ0_ABC *inst, double t, union uData *data, double *timestep)
{ // limit the timestep to a tolerance if the circuit causes a change in struct sDQ0_ABC
   const double ttol = 1e-9;
   if(*timestep > ttol)
   {
      double &a     = data[4].d; // output
      double &b     = data[5].d; // output
      double &c     = data[6].d; // output

      // Save output vector
      const double _a     = a    ;
      const double _b     = b    ;
      const double _c     = c    ;

      struct sDQ0_ABC tmp = *inst;
      dq0_abc(&(&tmp), t, data);
   // if(tmp != *inst) // implement a meaningful way to detect if the state has changed
   //    *timestep = ttol;

      // Restore output vector
      a     = _a    ;
      b     = _b    ;
      c     = _c    ;
   }
}

extern "C" __declspec(dllexport) void Destroy(struct sDQ0_ABC *inst)
{
   free(inst);
}
