// Automatically generated C++ file on Thu Jul  4 14:56:01 2024
//
// To build with Digital Mars C++ Compiler:
//
//    dmc -mn -WD rectifier_control.cpp kernel32.lib

#include <stdio.h>
#include <malloc.h>
#include <stdarg.h>
#include <time.h>
#include <math.h>

union uData
{
   bool b;
   char c;
   unsigned char uc;
   short s;
   unsigned short us;
   int i;
   unsigned int ui;
   float f;
   double d;
   long long int i64;
   unsigned long long int ui64;
   char *str;
   unsigned char *bytes;
};

// int DllMain() must exist and return 1 for a process to load the .DLL
// See https://docs.microsoft.com/en-us/windows/win32/dlls/dllmain for more information.
int __stdcall DllMain(void *module, unsigned int reason, void *reserved) { return 1; }

void display(const char *fmt, ...)
{ // for diagnostic print statements
   va_list args;
   va_start(args, fmt);
   vprintf(fmt, args);
   va_end(args);
}

void bzero(void *ptr, unsigned int count)
{
   unsigned char *first = (unsigned char *) ptr;
   unsigned char *last  = first + count;
   while(first < last)
      *first++ = '\0';
}

// #undef pin names lest they collide with names in any header file(s) you might include.
#undef ctrl_d
#undef Vdc
#undef Id
#undef Iq
#undef Vd
#undef Vq
#undef ctrl_q
#undef ed
#undef eq

struct sRECTIFIER_CONTROL
{
   double ed;
   double eq;
};

extern "C" __declspec(dllexport) void rectifier_control(struct sRECTIFIER_CONTROL **opaque, double t, union uData *data)
{
   double  ctrl_d = data[0].d; // input
   double  Vdc    = data[1].d; // input
   double  Id     = data[2].d; // input
   double  Iq     = data[3].d; // input
   double  Vd     = data[4].d; // input
   double  Vq     = data[5].d; // input
   double  ctrl_q = data[6].d; // input
   double &ed     = data[7].d; // output
   double &eq     = data[8].d; // output

   if(!*opaque)
   {
      *opaque = (struct sRECTIFIER_CONTROL *) malloc(sizeof(struct sRECTIFIER_CONTROL));
      bzero(*opaque, sizeof(struct sRECTIFIER_CONTROL));
   }
   struct sRECTIFIER_CONTROL *inst = *opaque;

// Implement module evaluation code here:
   ed = (-ctrl_d + (2 * M_PI * 50 * 0.000029 * Iq) + Vd) * 2/Vdc;
   eq = (-ctrl_q - (2 * M_PI * 50 * 0.000029 * Id) + Vq) * 2/Vdc;

   inst->ed = ed;
   inst->eq = eq;
}

extern "C" __declspec(dllexport) double MaxExtStepSize(struct sRECTIFIER_CONTROL *inst)
{
   return 1e308; // implement a good choice of max timestep size that depends on struct sRECTIFIER_CONTROL
}

extern "C" __declspec(dllexport) void Trunc(struct sRECTIFIER_CONTROL *inst, double t, union uData *data, double *timestep)
{ // limit the timestep to a tolerance if the circuit causes a change in struct sRECTIFIER_CONTROL
   const double ttol = 1e-9;
   if(*timestep > ttol)
   {
      double &ed     = data[7].d; // output
      double &eq     = data[8].d; // output

      // Save output vector
      const double _ed     = ed    ;
      const double _eq     = eq    ;

      struct sRECTIFIER_CONTROL tmp = *inst;
      rectifier_control(&(&tmp), t, data);
      if (tmp.ed != inst->ed || tmp.eq != inst->eq) // implement a meaningful way to detect if the state has changed
         *timestep = ttol;

      // Restore output vector
      ed     = _ed    ;
      eq     = _eq    ;
   }
}

extern "C" __declspec(dllexport) void Destroy(struct sRECTIFIER_CONTROL *inst)
{
   free(inst);
}
