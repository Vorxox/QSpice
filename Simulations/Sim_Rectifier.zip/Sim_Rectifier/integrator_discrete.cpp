#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <cstdlib>
// Define a union to hold various types of data
union uData {
    bool b;
    char c;
    unsigned char uc;
    short s;
    unsigned short us;
    int i;
    unsigned int ui;
    float f;
    double d;
    long long int i64;
    unsigned long long int ui64;
    char *str;
    unsigned char *bytes;
};

// Global variables for the integrator state
double y_prev = 0.0;  // y(n-1), previous output value
double u_prev = 0.0;  // u(n-1), previous input value

// Function to compute the new output value y(n) using numerical integration
double integrator(double u, double T) {
    double y;  // y(n), current output value

    // Numerical integrator using the trapezoidal rule
    y = y_prev + (T / 2.0) * (u + u_prev);

    // Update previous values for the next iteration
    y_prev = y;
    u_prev = u;

    return y;
}

// int DllMain() must exist and return 1 for a process to load the .DLL
// See https://docs.microsoft.com/en-us/windows/win32/dlls/dllmain for more information.
int __stdcall DllMain(void *module, unsigned int reason, void *reserved) { return 1; }

// #undef pin names lest they collide with names in any header file(s) you might include.
#undef u
#undef y

// Function to integrate with QSpice
extern "C" __declspec(dllexport) void integrator_discrete(void **opaque, double t, union uData *data) {
    double u = data[0].d; // input
    double &y = data[1].d; // output
    double T = 1.0 / 10000.0; // Sampling period (10,000 Hz)

    // Compute the new output value using the integrator function
    y = integrator(u, T);

    // Update the output in the data array
    data[1].d = y;
}
