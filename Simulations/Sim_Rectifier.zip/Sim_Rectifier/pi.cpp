#include <stdio.h>
#include <malloc.h>
#include <stdarg.h>
#include <time.h>
#include <cstdlib>

union uData {
    bool b;
    char c;
    unsigned char uc;
    short s;
    unsigned short us;
    int i;
    unsigned int ui;
    float f;
    double d;
    long long int i64;
    unsigned long long int ui64;
    char *str;
    unsigned char *bytes;
};

// int DllMain() must exist and return 1 for a process to load the .DLL
// See https://docs.microsoft.com/en-us/windows/win32/dlls/dllmain for more information.
int __stdcall DllMain(void *module, unsigned int reason, void *reserved) { return 1; }

void display(const char *fmt, ...) {
    // for diagnostic print statements
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
    fflush(stdout);
}

void bzero(void *ptr, unsigned int count) {
    unsigned char *first = (unsigned char *) ptr;
    unsigned char *last = first + count;
    while (first < last) {
        *first++ = '\0';
    }
}

// #undef pin names lest they collide dengan nama di file header yang mungkin Anda sertakan.
#undef Ref
#undef Fb
#undef Kp
#undef Ki
#undef Kd
#undef out

struct sPI {
    bool clk_n1;          // previous clock state
    double integral;      // to store the integral term
    double last_error;    // to store the previous error
    double lastT;         // to store the last time
};

extern "C" __declspec(dllexport) void pi(struct sPI **opaque, double t, union uData *data) {
    double Ref = data[0].d; // input reference
    bool clk = data[1].b; // clock input
    double Fb = data[2].d; // feedback input
    double Kp = data[3].d; // proportional gain
    double Ki = data[4].d; // integral gain
    double Kd = data[5].d; // derivative gain
    double &out = data[6].d; // output

    if (!*opaque) {
        *opaque = (struct sPI *) malloc(sizeof(struct sPI));
        bzero(*opaque, sizeof(struct sPI));
    }

    struct sPI *inst = *opaque;

    if (clk && !inst->clk_n1) { // rising edge
        double Ts = t - inst->lastT; // Sampling period
        inst->lastT = t;

        double error = Ref - Fb;

        // Discrete integrator calculation
        inst->integral += error * Ts * (Ki / 2.0) + inst->last_error * Ts * (Ki / 2.0);

        // Discrete derivative calculation
        double derivative = (error - inst->last_error) / Ts;

        // PI controller output
        out = (Kp * error) + inst->integral + (Kd * derivative);

        // Update the output in the data array
        data[6].d = out;

        // Update the last error
        inst->last_error = error;
    }

    // Save previous clock state
    inst->clk_n1 = clk;
}

extern "C" __declspec(dllexport) double MaxExtStepSize(struct sPI *inst) {
    return 1e308; // implement a good choice of max timestep size that depends on struct sPI
}

extern "C" __declspec(dllexport) void Trunc(struct sPI *inst, double t, union uData *data, double *timestep) {
    const double ttol = 1e-9;
    if (*timestep > ttol) {
        double &out = data[6].d; // output

        // Save output vector
        const double _out = out;

        struct sPI tmp = *inst;
        struct sPI *ptmp = &tmp; // Create a pointer to tmp
        pi(&ptmp, t, data); // Pass the pointer to the pointer

        // Restore output vector
        out = _out;
    }
}

extern "C" __declspec(dllexport) void Destroy(struct sPI *inst) {
    free(inst);
}
